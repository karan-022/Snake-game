Hi, this is a snke game. 
This is built using HTML, CSS and JAVASCRIPT with many feature.
if you want to view or play go to- https://snake-game-76f356.netlify.app/
